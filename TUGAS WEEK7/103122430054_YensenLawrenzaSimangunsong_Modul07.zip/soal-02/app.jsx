const { useState, useEffect } = React;

const SKENARIO_CONFIG = {
  berhasil: {
    label: "Berhasil",
    url: "/api/users?delay=1000",
    timeout: 5000,
  },
  kosong: {
    label: "Data kosong",
    url: "/api/users?mode=empty&delay=1000",
    timeout: 5000,
  },
  error: {
    label: "Error HTTP",
    url: "/api/users?mode=error&delay=1000",
    timeout: 5000,
  },
  timeout: {
    label: "Timeout",
    url: "/api/users?delay=2500",
    timeout: 700,
  },
};

function App() {
  // State GET Peserta
  const [skenario, setSkenario] = useState("berhasil");
  const [users, setUsers] = useState([]);
  const [loadingGet, setLoadingGet] = useState(false);
  const [errorGet, setErrorGet] = useState(null);
  const [triggerReload, setTriggerReload] = useState(0);

  // State Form Pendaftaran POST
  const [nama, setNama] = useState("");
  const [email, setEmail] = useState("");
  const [formError, setFormError] = useState("");
  const [loadingPost, setLoadingPost] = useState(false);
  const [postResult, setPostResult] = useState(null);
  const [errorPost, setErrorPost] = useState(null);

  // Efek GET Peserta dengan AbortController & Penanda Efek Aktif
  useEffect(() => {
    const controller = new AbortController();
    let isCurrent = true;

    async function fetchUsers() {
      setLoadingGet(true);
      setErrorGet(null);
      setUsers([]);

      const target = SKENARIO_CONFIG[skenario];

      try {
        const response = await axios.get(target.url, {
          timeout: target.timeout,
          signal: controller.signal,
        });

        if (isCurrent) {
          setUsers(response.data || []);
        }
      } catch (err) {
        if (!isCurrent) return;

        if (axios.isCancel(err) || err.name === "CanceledError") {
          return; // Request dibatalkan karena perpindahan skenario
        }

        if (err.code === "ECONNABORTED" || (err.message && err.message.toLowerCase().includes("timeout"))) {
          setErrorGet(`Request timeout: Batas tunggu ${target.timeout} ms terlampaui sebelum respons server tiba.`);
        } else if (err.response) {
          setErrorGet(`HTTP Error ${err.response.status}: ${err.response.statusText || "Gagal memuat data dari server."}`);
        } else {
          setErrorGet(`Gangguan koneksi: ${err.message}`);
        }
      } finally {
        if (isCurrent) {
          setLoadingGet(false);
        }
      }
    }

    fetchUsers();

    return () => {
      isCurrent = false;
      controller.abort();
    };
  }, [skenario, triggerReload]);

  // Validasi format email
  const isValidEmail = (val) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val);
  };

  // Handler Kirim Form POST
  const handleSubmit = async (e) => {
    e.preventDefault();
    setFormError("");
    setPostResult(null);
    setErrorPost(null);

    const cleanNama = nama.trim();
    const cleanEmail = email.trim();

    // Validasi Sisi Klien
    if (!cleanNama) {
      setFormError("Nama tidak boleh kosong atau hanya berupa spasi.");
      return;
    }
    if (!cleanEmail) {
      setFormError("Email tidak boleh kosong.");
      return;
    }
    if (!isValidEmail(cleanEmail)) {
      setFormError("Format email tidak valid. Masukkan format email yang benar (contoh: rina@example.com).");
      return;
    }

    setLoadingPost(true);
    try {
      const payload = { name: cleanNama, email: cleanEmail };
      const res = await axios.post("/api/users", payload);

      setPostResult({
        status: res.status,
        data: res.data,
      });

      // Reset input form setelah berhasil
      setNama("");
      setEmail("");
    } catch (err) {
      if (err.response) {
        setErrorPost(`HTTP Error ${err.response.status}: Pengiriman pendaftaran gagal.`);
      } else {
        setErrorPost(`Gangguan koneksi: ${err.message}`);
      }
    } finally {
      setLoadingPost(false);
    }
  };

  return (
    <div>
      <h1>Aplikasi Registrasi Peserta (React & Axios)</h1>

      {/* Bagian 1: Daftar Peserta (GET) */}
      <section className="card">
        <h2>Daftar Peserta (GET)</h2>
        <div style={{ display: "flex", gap: "12px", alignItems: "center", marginBottom: "16px", flexWrap: "wrap" }}>
          <label htmlFor="skenario-select"><strong>Skenario GET:</strong></label>
          <select
            id="skenario-select"
            value={skenario}
            onChange={(e) => setSkenario(e.target.value)}
            style={{ padding: "6px 10px" }}
          >
            {Object.keys(SKENARIO_CONFIG).map((key) => (
              <option key={key} value={key}>
                {SKENARIO_CONFIG[key].label}
              </option>
            ))}
          </select>

          <button
            type="button"
            onClick={() => setTriggerReload((prev) => prev + 1)}
            disabled={loadingGet}
          >
            {loadingGet ? "Memuat..." : "Muat ulang"}
          </button>
        </div>

        {/* Status Loading */}
        {loadingGet && (
          <div className="status-box alert-warning">
            Sedang memuat data peserta ({SKENARIO_CONFIG[skenario].label})...
          </div>
        )}

        {/* Status Error */}
        {errorGet && !loadingGet && (
          <div className="status-box alert-error">
            <strong>Gagal:</strong> {errorGet}
          </div>
        )}

        {/* Status Data Kosong */}
        {!loadingGet && !errorGet && users.length === 0 && (
          <div className="status-box alert-warning">
            Data kosong. Tidak ada peserta yang terdaftar pada skenario ini.
          </div>
        )}

        {/* Daftar Peserta Berhasil */}
        {!loadingGet && !errorGet && users.length > 0 && (
          <ul style={{ listStyle: "disc", paddingLeft: "24px" }}>
            {users.map((u) => (
              <li key={u.id} style={{ marginBottom: "6px" }}>
                <strong>{u.name}</strong> - <span>{u.email}</span>
              </li>
            ))}
          </ul>
        )}
      </section>

      {/* Bagian 2: Form Pendaftaran (POST) */}
      <section className="card">
        <h2>Formulir Pendaftaran Peserta (POST)</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="input-nama">Nama Lengkap:</label>
            <input
              id="input-nama"
              type="text"
              value={nama}
              onChange={(e) => setNama(e.target.value)}
              placeholder="Contoh: Rina Praktikan"
              disabled={loadingPost}
            />
          </div>

          <div className="form-group">
            <label htmlFor="input-email">Alamat Email:</label>
            <input
              id="input-email"
              type="text"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Contoh: rina@example.com"
              disabled={loadingPost}
            />
          </div>

          {formError && (
            <div className="status-box alert-error">
              <strong>Peringatan Validasi:</strong> {formError}
            </div>
          )}

          <button type="submit" disabled={loadingPost}>
            {loadingPost ? "Mengirim pendaftaran..." : "Kirim pendaftaran"}
          </button>
        </form>

        {/* Status Error POST */}
        {errorPost && (
          <div className="status-box alert-error" style={{ marginTop: "14px" }}>
            <strong>Pengiriman Gagal:</strong> {errorPost}
          </div>
        )}

        {/* Hasil Berhasil POST */}
        {postResult && (
          <div className="post-result">
            <h3 style={{ margin: "0 0 8px 0", color: "#1a7f37" }}>
              Simulasi berhasil, data tidak disimpan.
            </h3>
            <p style={{ margin: "4px 0" }}><strong>Status HTTP:</strong> {postResult.status}</p>
            <p style={{ margin: "4px 0" }}><strong>ID:</strong> {postResult.data?.id}</p>
            <p style={{ margin: "4px 0" }}><strong>Nama:</strong> {postResult.data?.name}</p>
            <p style={{ margin: "4px 0" }}><strong>Email:</strong> {postResult.data?.email}</p>
            <p style={{ margin: "4px 0" }}><strong>Simulated:</strong> {String(postResult.data?.simulated)}</p>
          </div>
        )}
      </section>
    </div>
  );
}

// Inisialisasi Root ReactDOM
const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
