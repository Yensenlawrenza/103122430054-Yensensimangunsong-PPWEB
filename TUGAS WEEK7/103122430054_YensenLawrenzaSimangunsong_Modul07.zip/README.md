# Praktikum Modul 07 - AJAX dan Konsumsi API

Proyek ini berisi penyelesaian tugas praktikum Modul 07 untuk Soal 01 dan Soal 02.

## Struktur Berkas
```
.
├── soal-01/
│   ├── index.html
│   ├── app.js
│   └── pengumuman.txt
├── soal-02/
│   ├── index.html
│   └── app.jsx
├── README.md
└── LAPORAN_PENGUJIAN.md
```

## Persiapan & Cara Menjalankan
1. Pastikan Node.js v18 atau lebih baru telah terpasang.
2. Tempatkan folder `soal-01` dan `soal-02` ke dalam folder `latihan-praktikan/` pada paket modul:
   - `Paket_Praktikum_AJAX/latihan-praktikan/soal-01`
   - `Paket_Praktikum_AJAX/latihan-praktikan/soal-02`
3. Jalankan server lokal dari folder utama paket modul:
   ```bash
   node server.cjs
   ```
   Atau jalankan file `JALANKAN.bat`.
4. Buka browser pada alamat:
   - **Soal 01:** `http://127.0.0.1:3007/latihan-praktikan/soal-01/`
   - **Soal 02:** `http://127.0.0.1:3007/latihan-praktikan/soal-02/`
