document.addEventListener("DOMContentLoaded", () => {
  // 1. Status awal dan interaksi non-blocking
  const waktuBukaEl = document.getElementById("waktu-buka");
  const nilaiHitunganEl = document.getElementById("nilai-hitungan");
  const btnHitung = document.getElementById("btn-hitung");
  
  let hitungan = 0;
  waktuBukaEl.textContent = new Date().toLocaleTimeString("id-ID");

  btnHitung.addEventListener("click", () => {
    hitungan++;
    nilaiHitunganEl.textContent = hitungan;
  });

  // 2. Pengumuman menggunakan XMLHttpRequest (XHR)
  const btnMuatPengumuman = document.getElementById("btn-muat-pengumuman");
  const kontenPengumuman = document.getElementById("konten-pengumuman");
  const statusPengumuman = document.getElementById("status-pengumuman");

  function setStatusPengumuman(pesan, tipe) {
    if (!pesan) {
      statusPengumuman.style.display = "none";
      return;
    }
    statusPengumuman.style.display = "inline-block";
    statusPengumuman.textContent = pesan;
    statusPengumuman.className = `status-badge status-${tipe}`;
  }

  btnMuatPengumuman.addEventListener("click", () => {
    const xhr = new XMLHttpRequest();
    const url = "pengumuman.txt"; // Ubah sementara ke 'hilang.txt' untuk skenario uji 404

    btnMuatPengumuman.disabled = true;
    setStatusPengumuman("Memuat berkas pengumuman...", "loading");

    xhr.open("GET", url, true);

    xhr.onreadystatechange = function () {
      if (xhr.readyState === XMLHttpRequest.DONE) {
        btnMuatPengumuman.disabled = false;
        if (xhr.status === 200) {
          kontenPengumuman.textContent = xhr.responseText;
          setStatusPengumuman("Pengumuman berhasil dimuat.", "success");
        } else if (xhr.status === 404) {
          kontenPengumuman.textContent = "Gagal memuat pengumuman.";
          setStatusPengumuman("Error 404: Berkas pengumuman tidak ditemukan.", "error");
        } else {
          kontenPengumuman.textContent = "Gagal mengambil berkas.";
          setStatusPengumuman(`HTTP Gagal: ${xhr.status} (${xhr.statusText || "Terjadi kesalahan"})`, "error");
        }
      }
    };

    xhr.onerror = function () {
      btnMuatPengumuman.disabled = false;
      kontenPengumuman.textContent = "Koneksi jaringan terputus.";
      setStatusPengumuman("Gangguan jaringan saat memuat berkas pengumuman.", "error");
    };

    xhr.send();
  });

  // 3. Direktori Peserta menggunakan Fetch API
  const selectSumber = document.getElementById("select-sumber");
  const btnAmbilPeserta = document.getElementById("btn-ambil-peserta");
  const statusPeserta = document.getElementById("status-peserta");
  const hasilPesertaContainer = document.getElementById("hasil-peserta-container");
  const labelSumber = document.getElementById("label-sumber");
  const labelJumlah = document.getElementById("label-jumlah");
  const daftarPeserta = document.getElementById("daftar-peserta");

  function setStatusPeserta(pesan, tipe) {
    if (!pesan) {
      statusPeserta.style.display = "none";
      return;
    }
    statusPeserta.style.display = "block";
    statusPeserta.textContent = pesan;
    statusPeserta.className = `status-badge status-${tipe}`;
  }

  btnAmbilPeserta.addEventListener("click", () => {
    const pilihan = selectSumber.value;
    let url = "";
    let namaSumber = "";

    if (pilihan === "mock") {
      url = "/api/users?delay=1500";
      namaSumber = "Mock Server Lokal";
    } else {
      url = "https://jsonplaceholder.typicode.com/users";
      namaSumber = "JSONPlaceholder Eksternal";
    }

    btnAmbilPeserta.disabled = true;
    setStatusPeserta(`Sedang mengambil data peserta dari ${namaSumber}...`, "loading");

    fetch(url)
      .then((response) => {
        if (!response.ok) {
          throw new Error(`HTTP ${response.status} (${response.statusText})`);
        }
        return response.json();
      })
      .then((data) => {
        if (!Array.isArray(data)) {
          throw new Error("Format respons bukan berupa array.");
        }

        const tampilData = data.slice(0, 3);
        daftarPeserta.innerHTML = "";

        if (tampilData.length === 0) {
          daftarPeserta.innerHTML = "<li class='user-item'>Tidak ada data peserta ditemukan.</li>";
        } else {
          tampilData.forEach((user) => {
            const li = document.createElement("li");
            li.className = "user-item";
            li.innerHTML = `<strong>${user.name}</strong> &lt;${user.email}&gt;`;
            daftarPeserta.appendChild(li);
          });
        }

        labelSumber.textContent = namaSumber;
        labelJumlah.textContent = tampilData.length;
        hasilPesertaContainer.style.display = "block";
        setStatusPeserta("Data peserta berhasil diambil.", "success");
      })
      .catch((err) => {
        daftarPeserta.innerHTML = "";
        hasilPesertaContainer.style.display = "none";
        if (pilihan === "eksternal") {
          setStatusPeserta(`API Eksternal gagal: ${err.message}. Silakan periksa koneksi internet Anda atau pilih opsi Mock Lokal secara manual.`, "error");
        } else {
          setStatusPeserta(`Gagal memuat peserta: ${err.message}`, "error");
        }
      })
      .finally(() => {
        btnAmbilPeserta.disabled = false;
      });
  });
});
