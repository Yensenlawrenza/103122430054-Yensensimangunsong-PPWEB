# Laporan Pengujian Praktikum Modul 07

**Nama Praktikan:** Yensen Lawrenza Simangunsong  
**NIM:** 103122430054  
**Kelas:** SE-08-02  

---

## 1. Tabel Hasil Uji Skenario

| Soal | Skenario Pengujian | Langkah Pengujian | Hasil Aktual yang Terlihat | Status |
| :---: | :--- | :--- | :--- | :---: |
| **1** | Memuat & Mengubah Pengumuman (XHR) | Klik *Muat pengumuman*, ubah teks `pengumuman.txt`, lalu klik lagi | Isi teks baru langsung tampil tanpa reload halaman. | **Berhasil** |
| **1** | Pengujian Berkas Tidak Ada (404) | Ganti sementara URL pengumuman ke `hilang.txt` | Muncul pesan status 'Error 404: Berkas pengumuman tidak ditemukan.' | **Berhasil** |
| **1** | Interaksi Non-Blocking saat Menunggu | Klik *Ambil peserta* (Mock), segera ketik di Catatan & klik *Tambah hitungan* 3x | Catatan praktikan tetap utuh, hitungan bertambah menjadi 3, waktu awal tetap sama, 3 peserta muncul setelah 1.5s. | **Berhasil** |
| **1** | Direktori API Eksternal | Pilih sumber *JSONPlaceholder*, klik *Ambil peserta* | Maksimal 3 peserta pertama tampil beserta email, nama sumber, dan jumlah data (3). | **Berhasil** |
| **2** | Auto-Load GET Awal & Muat Ulang | Buka halaman Soal 02, lalu klik tombol *Muat ulang* | Request GET berjalan otomatis saat komponen mount (`useEffect`); tombol memicu pemuatan ulang. | **Berhasil** |
| **2** | Skenario Data Kosong & Error HTTP | Pilih skenario *Data kosong*, kemudian ubah ke *Error HTTP* | *Data kosong* menampilkan peringatan data kosong; *Error HTTP* menampilkan pesan 'HTTP Error 503'. Daftar lama dibersihkan. | **Berhasil** |
| **2** | Skenario Timeout Axios (700 ms) | Pilih skenario *Timeout* (delay server 2500 ms, limit 700 ms) | Request gagal tepat pada batas 700 ms dengan pesan timeout; tombol & kontrol dapat dipakai kembali. | **Berhasil** |
| **2** | Pergantian Skenario Cepat (Race Condition) | Pilih skenario *Timeout*, lalu dengan cepat klik skenario *Berhasil* | Request timeout dibatalkan oleh `AbortController`; data yang tampil hanya skenario *Berhasil*. | **Berhasil** |
| **2** | Validasi Input Formulir POST | Kirim form dengan nama kosong/spasi saja, atau format email tanpa '@' | Form menolak pengiriman dan menampilkan petunjuk perbaikan yang jelas. | **Berhasil** |
| **2** | Pengiriman Registrasi POST Axios | Masukkan nama 'Rina Praktikan' dan email 'rina@example.com', lalu kirim | Muncul kotak hasil POST: Status 201, ID 101, data sesuai input, simulated true. Daftar GET tetap tidak terpengaruh. | **Berhasil** |

---

## 2. Penjelasan Singkat Alur Teknis

1. **XMLHttpRequest (XHR):**  
   Diterapkan secara asinkron (`open("GET", url, true)`). Memanfaatkan *event listener* `onreadystatechange` untuk memeriksa apakah `readyState === 4` (DONE) serta validasi status HTTP (`200` atau `404`) sebelum memanipulasi teks elemen `<pre>` pada DOM.
2. **Fetch API:**  
   Menggunakan antarmuka Promise (`fetch().then().catch().finally()`). Pengecekan `response.ok` dilakukan secara eksplisit sebelum parsing JSON untuk menangani kegagalan HTTP status, dilengkapi pemotongan data menggunakan `.slice(0, 3)`.
3. **Axios GET & POST:**  
   Mempermudah penanganan request dengan otomatis mengonversi response JSON ke properti `response.data`. Mendukung batas waktu request (`timeout: 700`) yang secara otomatis menghasilkan error `ECONNABORTED` saat batas terlampaui.
4. **Peran State & Effect pada React:**  
   - `useState` mengelola data peserta, status loading, error, nilai input formulir, dan hasil POST secara reaktif.
   - `useEffect` memicu GET awal dan mengeksekusi request baru saat dropdown skenario berubah.
   - Pemanfaatan `AbortController` di dalam fungsi *cleanup* `useEffect` mencegah *race condition* dan *memory leak* dari respons asinkron lama yang terlambat datang.
